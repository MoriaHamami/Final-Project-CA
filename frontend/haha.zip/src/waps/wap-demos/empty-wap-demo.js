
export const emptyWapDemo = {
	_id: '123',
	name: 'Start from Scratch',
	// TODO: replace picture with plus image
	imgUrl: 'https://res.cloudinary.com/dimirmc9j/image/upload/v1674125480/add-template_ooawuz.png',
	info : {},
	cmps: [],
	isPublic: true
}





