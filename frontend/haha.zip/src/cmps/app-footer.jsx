

import { UserMsg } from './user-msg.jsx'

export function AppFooter() {
    return (
        <footer className="app-footer">
            <p>
                coffeerights - count
            </p>
          
            <UserMsg />
        </footer>
    )
}