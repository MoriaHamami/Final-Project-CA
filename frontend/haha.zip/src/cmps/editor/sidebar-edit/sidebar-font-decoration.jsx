
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faUnderline } from '@fortawesome/free-solid-svg-icons'


export function SidebarFontDecoration({title,  onChange}) {

    function onChangeRange({target}){
        target.title = target.value
        onChange('font-weight', target.value)
    
    }

        return <div>
          <span>{title}</span>
          <div className="editor-decoration--container">

          </div>
        </div>
        // value={chosenContainer.style}
    }